
package com.mycompany.qlhssv20.model;

public class BaoCao {

    private String maSV;
    private String hoTen;
    private String lop;
    private String maMonHoc;
    private String tenMonHoc;
    private Double diemQuaTrinh;
    private Double diemThi;
    private Double diemTongKet;

    public BaoCao(String maSV, String hoTen, String lop,
                  String maMonHoc, String tenMonHoc,
                  Double diemQuaTrinh, Double diemThi,
                  Double diemTongKet) {
        this.maSV = maSV;
        this.hoTen = hoTen;
        this.lop = lop;
        this.maMonHoc = maMonHoc;
        this.tenMonHoc = tenMonHoc;
        this.diemQuaTrinh = diemQuaTrinh;
        this.diemThi = diemThi;
        this.diemTongKet = diemTongKet;
    }

    public String getMaSV() {
        return maSV;
    }

    public String getHoTen() {
        return hoTen;
    }

    public String getLop() {
        return lop;
    }

    public String getMaMonHoc() {
        return maMonHoc;
    }

    public String getTenMonHoc() {
        return tenMonHoc;
    }

    public Double getDiemQuaTrinh() {
        return diemQuaTrinh;
    }

    public Double getDiemThi() {
        return diemThi;
    }

    public Double getDiemTongKet() {
        return diemTongKet;
    }
}
