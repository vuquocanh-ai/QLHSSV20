
package com.mycompany.qlhssv20.view;

import com.mycompany.qlhssv20.dao.BaoCaoDAO;
import com.mycompany.qlhssv20.model.BaoCao;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.sql.SQLException;
import java.util.List;

public class BaoCaoView extends JPanel {

    private final BaoCaoDAO dao = new BaoCaoDAO();

    private final JComboBox<String> cboLoai = new JComboBox<>(
            new String[]{"Danh sách sinh viên", "Bảng điểm"});

    private final DefaultTableModel model = new DefaultTableModel() {
        @Override
        public boolean isCellEditable(int row, int column) {
            return false;
        }
    };

    private final JTable table = new JTable(model);

    public BaoCaoView() {
        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        JLabel title = new JLabel("BÁO CÁO");
        title.setFont(new Font("Arial", Font.BOLD, 22));

        JButton btnXem = new JButton("Xem báo cáo");
        JButton btnXuat = new JButton("Xuất CSV");

        JPanel top = new JPanel(new FlowLayout(FlowLayout.LEFT));
        top.add(new JLabel("Loại báo cáo:"));
        top.add(cboLoai);
        top.add(btnXem);
        top.add(btnXuat);

        JPanel north = new JPanel(new BorderLayout());
        north.add(title, BorderLayout.NORTH);
        north.add(top, BorderLayout.SOUTH);

        add(north, BorderLayout.NORTH);
        add(new JScrollPane(table), BorderLayout.CENTER);

        btnXem.addActionListener(e -> taiBaoCao());
        btnXuat.addActionListener(e -> xuatCSV());

        taiBaoCao();
    }

    private void taiBaoCao() {
        try {
            model.setRowCount(0);
            model.setColumnCount(0);

            if (cboLoai.getSelectedIndex() == 0) {
                model.setColumnIdentifiers(new String[]{
                    "Mã SV", "Họ tên", "Lớp"
                });

                List<BaoCao> list = dao.getDanhSachSinhVien();

                for (BaoCao b : list) {
                    model.addRow(new Object[]{
                        b.getMaSV(), b.getHoTen(), b.getLop()
                    });
                }
            } else {
                model.setColumnIdentifiers(new String[]{
                    "Mã SV", "Họ tên", "Lớp", "Mã môn",
                    "Tên môn", "Điểm quá trình", "Điểm thi",
                    "Điểm tổng kết"
                });

                List<BaoCao> list = dao.getBangDiem();

                for (BaoCao b : list) {
                    model.addRow(new Object[]{
                        b.getMaSV(), b.getHoTen(), b.getLop(),
                        b.getMaMonHoc(), b.getTenMonHoc(),
                        b.getDiemQuaTrinh(), b.getDiemThi(),
                        b.getDiemTongKet()
                    });
                }
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this,
                    "Lỗi tải báo cáo: " + ex.getMessage(),
                    "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void xuatCSV() {
        if (model.getColumnCount() == 0) {
            JOptionPane.showMessageDialog(this, "Không có dữ liệu để xuất.");
            return;
        }

        JFileChooser chooser = new JFileChooser();
        chooser.setSelectedFile(new File("BaoCao.csv"));

        if (chooser.showSaveDialog(this) != JFileChooser.APPROVE_OPTION) {
            return;
        }

        File file = chooser.getSelectedFile();

        try (Writer writer = new OutputStreamWriter(
                new FileOutputStream(file), StandardCharsets.UTF_8)) {

            writer.write('\uFEFF');

            for (int c = 0; c < model.getColumnCount(); c++) {
                if (c > 0) writer.write(",");
                ghiCSV(writer, model.getColumnName(c));
            }
            writer.write("\r\n");

            for (int r = 0; r < model.getRowCount(); r++) {
                for (int c = 0; c < model.getColumnCount(); c++) {
                    if (c > 0) writer.write(",");
                    Object value = model.getValueAt(r, c);
                    ghiCSV(writer, value == null ? "" : value.toString());
                }
                writer.write("\r\n");
            }

            JOptionPane.showMessageDialog(this,
                    "Xuất báo cáo thành công!");

        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this,
                    "Lỗi xuất file: " + ex.getMessage());
        }
    }

    private void ghiCSV(Writer writer, String value) throws IOException {
        writer.write('"');
        writer.write(value.replace("\"", "\"\""));
        writer.write('"');
    }
}
