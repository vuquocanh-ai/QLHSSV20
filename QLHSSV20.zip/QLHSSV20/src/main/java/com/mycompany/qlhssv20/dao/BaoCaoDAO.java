
package com.mycompany.qlhssv20.dao;

import com.mycompany.qlhssv20.model.BaoCao;
import com.mycompany.qlhssv20.model.DBConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class BaoCaoDAO {

    public List<BaoCao> getDanhSachSinhVien() throws SQLException {
        List<BaoCao> list = new ArrayList<>();

        String sql = """
            SELECT MaSV, HoTen, MaLop AS Lop
            FROM SinhVien
            ORDER BY MaSV
            """;

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                list.add(new BaoCao(
                    rs.getString("MaSV"),
                    rs.getString("HoTen"),
                    rs.getString("Lop"),
                    null, null, null, null, null
                ));
            }
        }

        return list;
    }

    public List<BaoCao> getBangDiem() throws SQLException {
        List<BaoCao> list = new ArrayList<>();

        String sql = """
            SELECT sv.MaSV, sv.HoTen, sv.MaLop AS Lop,
                   mh.MaMonHoc, mh.TenMonHoc,
                   d.DiemQuaTrinh, d.DiemThi, d.DiemTongKet
            FROM SinhVien sv
            JOIN Diem d ON sv.MaSV = d.MaSV
            JOIN MonHoc mh ON d.MaMonHoc = mh.MaMonHoc
            ORDER BY sv.MaSV, mh.MaMonHoc
            """;

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                list.add(new BaoCao(
                    rs.getString("MaSV"),
                    rs.getString("HoTen"),
                    rs.getString("Lop"),
                    rs.getString("MaMonHoc"),
                    rs.getString("TenMonHoc"),
                    getDouble(rs, "DiemQuaTrinh"),
                    getDouble(rs, "DiemThi"),
                    getDouble(rs, "DiemTongKet")
                ));
            }
        }

        return list;
    }

    private Double getDouble(ResultSet rs, String column)
            throws SQLException {
        double value = rs.getDouble(column);
        return rs.wasNull() ? null : value;
    }
}
