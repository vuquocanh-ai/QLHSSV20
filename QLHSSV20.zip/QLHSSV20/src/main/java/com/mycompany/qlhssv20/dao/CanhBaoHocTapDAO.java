
package com.mycompany.qlhssv20.dao;

import com.mycompany.qlhssv20.model.CanhBaoHocTap;
import com.mycompany.qlhssv20.model.DBConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class CanhBaoHocTapDAO {

    public List<CanhBaoHocTap> getCanhBao(String loai)
            throws SQLException {

        List<CanhBaoHocTap> list = new ArrayList<>();

        String dieuKien;

        if ("DIEM_THAP".equals(loai)) {
            dieuKien = "d.DiemTongKet < 5";
        } else if ("CHUA_CO_DIEM".equals(loai)) {
            dieuKien = "d.DiemTongKet IS NULL";
        } else {
            dieuKien =
                "(d.DiemTongKet < 5 OR d.DiemTongKet IS NULL)";
        }

        String sql = """
            SELECT sv.MaSV, sv.HoTen, sv.MaLop AS Lop,
                   mh.MaMonHoc, mh.TenMonHoc,
                   d.DiemTongKet
            FROM Diem d
            JOIN SinhVien sv ON sv.MaSV = d.MaSV
            JOIN MonHoc mh ON mh.MaMonHoc = d.MaMonHoc
            WHERE
            """ + dieuKien + """
            ORDER BY sv.MaSV, mh.MaMonHoc
            """;

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                double value = rs.getDouble("DiemTongKet");
                Double diem = rs.wasNull() ? null : value;

                String noiDung = diem == null
                        ? "Chưa có điểm tổng kết"
                        : "Điểm tổng kết dưới 5";

                list.add(new CanhBaoHocTap(
                    rs.getString("MaSV"),
                    rs.getString("HoTen"),
                    rs.getString("Lop"),
                    rs.getString("MaMonHoc"),
                    rs.getString("TenMonHoc"),
                    diem,
                    noiDung
                ));
            }
        }

        return list;
    }
}
