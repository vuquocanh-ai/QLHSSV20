
package com.mycompany.qlhssv20.view;

import com.mycompany.qlhssv20.dao.DiemDAO;
import com.mycompany.qlhssv20.model.Diem;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class DiemView extends JPanel {

    private final DiemDAO diemDAO = new DiemDAO();

    private final JTextField txtMaSV = new JTextField();
    private final JTextField txtMaMonHoc = new JTextField();
    private final JTextField txtDiemQuaTrinh = new JTextField();
    private final JTextField txtDiemThi = new JTextField();
    private final JTextField txtDiemTongKet = new JTextField();

    private final DefaultTableModel model = new DefaultTableModel(
        new String[]{"Mã sinh viên", "Mã môn học",
                     "Điểm quá trình", "Điểm thi", "Điểm tổng kết"}, 0
    ) {
        @Override
        public boolean isCellEditable(int row, int column) {
            return false;
        }
    };

    private final JTable table = new JTable(model);

    public DiemView() {
        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        JLabel title = new JLabel("QUẢN LÝ ĐIỂM SINH VIÊN");
        title.setFont(new Font("Arial", Font.BOLD, 22));
        title.setHorizontalAlignment(SwingConstants.CENTER);
        add(title, BorderLayout.NORTH);

        JPanel form = new JPanel(new GridLayout(5, 2, 8, 8));

        form.add(new JLabel("Mã sinh viên:"));
        form.add(txtMaSV);

        form.add(new JLabel("Mã môn học:"));
        form.add(txtMaMonHoc);

        form.add(new JLabel("Điểm quá trình (0-10):"));
        form.add(txtDiemQuaTrinh);

        form.add(new JLabel("Điểm thi (0-10):"));
        form.add(txtDiemThi);

        form.add(new JLabel("Điểm tổng kết (0-10):"));
        form.add(txtDiemTongKet);

        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 8));

        JButton btnThem = new JButton("Thêm");
        JButton btnSua = new JButton("Sửa");
        JButton btnXoa = new JButton("Xóa");
        JButton btnTaiLai = new JButton("Tải lại");
        JButton btnLamMoi = new JButton("Làm mới");

        buttons.add(btnThem);
        buttons.add(btnSua);
        buttons.add(btnXoa);
        buttons.add(btnTaiLai);
        buttons.add(btnLamMoi);

        JPanel top = new JPanel(new BorderLayout(5, 5));
        top.add(form, BorderLayout.CENTER);
        top.add(buttons, BorderLayout.SOUTH);

        add(top, BorderLayout.NORTH);
        add(new JScrollPane(table), BorderLayout.CENTER);

        btnThem.addActionListener(e -> themDiem());
        btnSua.addActionListener(e -> suaDiem());
        btnXoa.addActionListener(e -> xoaDiem());
        btnTaiLai.addActionListener(e -> loadData());
        btnLamMoi.addActionListener(e -> lamMoi());

        table.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                hienThiDongDuocChon();
            }
        });

        loadData();
    }

    private Double docDiem(JTextField field, String tenDiem) {
        String value = field.getText().trim();

        if (value.isEmpty()) {
            return null;
        }

        try {
            double diem = Double.parseDouble(value.replace(',', '.'));

            if (diem < 0 || diem > 10) {
                throw new IllegalArgumentException(
                    tenDiem + " phải nằm trong khoảng 0 đến 10."
                );
            }

            return diem;

        } catch (NumberFormatException ex) {
            throw new IllegalArgumentException(
                tenDiem + " phải là số hợp lệ."
            );
        }
    }

    private Diem docForm() {
        String maSV = txtMaSV.getText().trim();
        String maMon = txtMaMonHoc.getText().trim();

        if (maSV.isEmpty() || maMon.isEmpty()) {
            throw new IllegalArgumentException(
                "Vui lòng nhập mã sinh viên và mã môn học."
            );
        }

        return new Diem(
            maSV,
            maMon,
            docDiem(txtDiemQuaTrinh, "Điểm quá trình"),
            docDiem(txtDiemThi, "Điểm thi"),
            docDiem(txtDiemTongKet, "Điểm tổng kết")
        );
    }

    private void themDiem() {
        try {
            Diem d = docForm();

            if (diemDAO.insert(d)) {
                JOptionPane.showMessageDialog(this, "Thêm điểm thành công!");
                loadData();
                lamMoi();
            } else {
                JOptionPane.showMessageDialog(
                    this,
                    "Không thêm được điểm. Kiểm tra mã sinh viên, mã môn học "
                    + "và xem điểm đã tồn tại chưa."
                );
            }

        } catch (IllegalArgumentException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage());
        }
    }

    private void suaDiem() {
        try {
            Diem d = docForm();

            if (diemDAO.update(d)) {
                JOptionPane.showMessageDialog(this, "Cập nhật điểm thành công!");
                loadData();
                lamMoi();
            } else {
                JOptionPane.showMessageDialog(
                    this, "Không tìm thấy điểm cần sửa."
                );
            }

        } catch (IllegalArgumentException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage());
        }
    }

    private void xoaDiem() {
        String maSV = txtMaSV.getText().trim();
        String maMon = txtMaMonHoc.getText().trim();

        if (maSV.isEmpty() || maMon.isEmpty()) {
            JOptionPane.showMessageDialog(
                this, "Hãy chọn một dòng điểm trong bảng trước."
            );
            return;
        }

        int confirm = JOptionPane.showConfirmDialog(
            this,
            "Bạn có chắc muốn xóa điểm của sinh viên " + maSV
                + " ở môn " + maMon + "?",
            "Xác nhận xóa",
            JOptionPane.YES_NO_OPTION
        );

        if (confirm == JOptionPane.YES_OPTION) {
            if (diemDAO.delete(maSV, maMon)) {
                JOptionPane.showMessageDialog(this, "Xóa điểm thành công!");
                loadData();
                lamMoi();
            } else {
                JOptionPane.showMessageDialog(this, "Xóa điểm thất bại.");
            }
        }
    }

    private void loadData() {
        model.setRowCount(0);

        List<Diem> list = diemDAO.getAll();

        for (Diem d : list) {
            model.addRow(new Object[]{
                d.getMaSV(),
                d.getMaMonHoc(),
                d.getDiemQuaTrinh(),
                d.getDiemThi(),
                d.getDiemTongKet()
            });
        }
    }

    private void hienThiDongDuocChon() {
        int row = table.getSelectedRow();

        if (row >= 0) {
            txtMaSV.setText(String.valueOf(model.getValueAt(row, 0)));
            txtMaMonHoc.setText(String.valueOf(model.getValueAt(row, 1)));
            txtDiemQuaTrinh.setText(
                giaTriO(model.getValueAt(row, 2))
            );
            txtDiemThi.setText(giaTriO(model.getValueAt(row, 3)));
            txtDiemTongKet.setText(giaTriO(model.getValueAt(row, 4)));
        }
    }

    private String giaTriO(Object value) {
        return value == null ? "" : value.toString();
    }

    private void lamMoi() {
        txtMaSV.setText("");
        txtMaMonHoc.setText("");
        txtDiemQuaTrinh.setText("");
        txtDiemThi.setText("");
        txtDiemTongKet.setText("");
        table.clearSelection();
        txtMaSV.requestFocus();
    }
}
