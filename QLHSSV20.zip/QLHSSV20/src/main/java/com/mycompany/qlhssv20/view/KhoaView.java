
package com.mycompany.qlhssv20.view;

import com.mycompany.qlhssv20.dao.KhoaDAO;
import com.mycompany.qlhssv20.model.Khoa;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.SQLException;

public class KhoaView extends JPanel {

    private final Color NAVY = new Color(25, 42, 75);
    private final Color BLUE = new Color(49, 94, 168);
    private final Color BG = new Color(244, 247, 252);
    private final Color GREEN = new Color(32, 135, 83);
    private final Color RED = new Color(190, 55, 55);
    private final Color GRAY = new Color(100, 110, 125);

    private final KhoaDAO dao = new KhoaDAO();

    private JTextField txtMaKhoa;
    private JTextField txtTenKhoa;
    private JTextArea txtMoTa;
    private JTable tblKhoa;
    private DefaultTableModel model;

    public KhoaView() {
        setLayout(new BorderLayout(12, 12));
        setBackground(BG);

        JLabel title = new JLabel("QUẢN LÝ KHOA");
        title.setFont(new Font("Arial", Font.BOLD, 20));
        title.setForeground(NAVY);

        JPanel form = new JPanel(new GridLayout(3, 2, 12, 10));
        form.setBackground(Color.WHITE);
        form.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createTitledBorder("THÔNG TIN KHOA"),
                BorderFactory.createEmptyBorder(12, 12, 12, 12)));

        txtMaKhoa = new JTextField();
        txtTenKhoa = new JTextField();
        txtMoTa = new JTextArea(3, 20);
        txtMoTa.setLineWrap(true);
        txtMoTa.setWrapStyleWord(true);

        form.add(new JLabel("Mã khoa:"));
        form.add(txtMaKhoa);
        form.add(new JLabel("Tên khoa:"));
        form.add(txtTenKhoa);
        form.add(new JLabel("Mô tả:"));
        form.add(new JScrollPane(txtMoTa));

        JButton btnThem = new JButton("＋ Thêm");
        JButton btnSua = new JButton("✎ Sửa");
        JButton btnXoa = new JButton("✕ Xóa");
        JButton btnMoi = new JButton("Làm mới");
        JButton btnTaiLai = new JButton("↻ Tải danh sách");

        styleButton(btnThem, GREEN);
        styleButton(btnSua, BLUE);
        styleButton(btnXoa, RED);
        styleButton(btnMoi, GRAY);
        styleButton(btnTaiLai, NAVY);

        JPanel buttons = new JPanel(
                new FlowLayout(FlowLayout.LEFT, 8, 8));
        buttons.setBackground(BG);
        buttons.add(btnThem);
        buttons.add(btnSua);
        buttons.add(btnXoa);
        buttons.add(btnMoi);
        buttons.add(btnTaiLai);

        JPanel top = new JPanel();
        top.setLayout(new BoxLayout(top, BoxLayout.Y_AXIS));
        top.setBackground(BG);
        top.add(title);
        top.add(Box.createVerticalStrut(12));
        top.add(form);
        top.add(buttons);

        model = new DefaultTableModel(
                new String[]{"Mã khoa", "Tên khoa", "Mô tả"}, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        tblKhoa = new JTable(model);
        tblKhoa.setRowHeight(28);
        tblKhoa.setSelectionMode(
                ListSelectionModel.SINGLE_SELECTION);

        JScrollPane scroll = new JScrollPane(tblKhoa);
        scroll.setBorder(BorderFactory.createTitledBorder(
                "DANH SÁCH KHOA"));

        add(top, BorderLayout.NORTH);
        add(scroll, BorderLayout.CENTER);

        btnThem.addActionListener(e -> themKhoa());
        btnSua.addActionListener(e -> suaKhoa());
        btnXoa.addActionListener(e -> xoaKhoa());
        btnMoi.addActionListener(e -> lamMoi());
        btnTaiLai.addActionListener(e -> loadData());

        tblKhoa.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                hienThiThongTin();
            }
        });

        loadData();
    }

    private void styleButton(JButton button, Color color) {
        button.setFont(new Font("Arial", Font.BOLD, 12));
        button.setForeground(Color.WHITE);
        button.setBackground(color);
        button.setFocusPainted(false);
        button.setBorderPainted(false);
        button.setPreferredSize(new Dimension(135, 36));
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
    }

    private void loadData() {
        try {
            model.setRowCount(0);

            for (Khoa khoa : dao.getAll()) {
                model.addRow(new Object[]{
                    khoa.getMaKhoa(),
                    khoa.getTenKhoa(),
                    khoa.getMoTa()
                });
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this,
                    "Không tải được danh sách khoa:\n"
                    + ex.getMessage(),
                    "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void themKhoa() {
        String ma = txtMaKhoa.getText().trim();
        String ten = txtTenKhoa.getText().trim();
        String moTa = txtMoTa.getText().trim();

        if (ma.isEmpty() || ten.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    "Vui lòng nhập mã khoa và tên khoa.");
            return;
        }

        try {
            if (dao.insert(new Khoa(ma, ten, moTa))) {
                JOptionPane.showMessageDialog(this,
                        "Thêm khoa thành công!");
                loadData();
                lamMoi();
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this,
                    "Không thêm được khoa:\n" + ex.getMessage(),
                    "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void suaKhoa() {
        String ma = txtMaKhoa.getText().trim();
        String ten = txtTenKhoa.getText().trim();
        String moTa = txtMoTa.getText().trim();

        if (ma.isEmpty() || ten.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    "Hãy chọn khoa và nhập tên khoa.");
            return;
        }

        try {
            if (dao.update(new Khoa(ma, ten, moTa))) {
                JOptionPane.showMessageDialog(this,
                        "Cập nhật khoa thành công!");
                loadData();
                lamMoi();
            } else {
                JOptionPane.showMessageDialog(this,
                        "Không tìm thấy khoa cần sửa.");
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this,
                    "Không sửa được khoa:\n" + ex.getMessage(),
                    "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void xoaKhoa() {
        String ma = txtMaKhoa.getText().trim();

        if (ma.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    "Hãy chọn khoa cần xóa.");
            return;
        }

        int confirm = JOptionPane.showConfirmDialog(this,
                "Bạn có chắc muốn xóa khoa " + ma + "?",
                "Xác nhận xóa", JOptionPane.YES_NO_OPTION);

        if (confirm != JOptionPane.YES_OPTION) {
            return;
        }

        try {
            if (dao.delete(ma)) {
                JOptionPane.showMessageDialog(this,
                        "Xóa khoa thành công!");
                loadData();
                lamMoi();
            } else {
                JOptionPane.showMessageDialog(this,
                        "Không tìm thấy khoa cần xóa.");
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this,
                    "Không xóa được khoa:\n" + ex.getMessage(),
                    "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void hienThiThongTin() {
        int row = tblKhoa.getSelectedRow();

        if (row >= 0) {
            txtMaKhoa.setText(
                    String.valueOf(model.getValueAt(row, 0)));
            txtTenKhoa.setText(
                    String.valueOf(model.getValueAt(row, 1)));

            Object moTa = model.getValueAt(row, 2);
            txtMoTa.setText(moTa == null ? "" : moTa.toString());

            txtMaKhoa.setEditable(false);
        }
    }

    private void lamMoi() {
        txtMaKhoa.setText("");
        txtTenKhoa.setText("");
        txtMoTa.setText("");
        txtMaKhoa.setEditable(true);
        tblKhoa.clearSelection();
    }
}
