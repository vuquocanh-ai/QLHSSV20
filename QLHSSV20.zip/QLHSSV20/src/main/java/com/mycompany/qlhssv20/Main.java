
package com.mycompany.qlhssv20;

import com.mycompany.qlhssv20.controller.SinhVienController;
import com.mycompany.qlhssv20.view.SinhVienView;
import javax.swing.SwingUtilities;

public class Main {

   public static void main(String[] args) {
    SwingUtilities.invokeLater(() -> {
        new com.mycompany.qlhssv20.view.LoginView().setVisible(true);
    });
}
}
