
package com.mycompany.qlhssv20.view;

import com.mycompany.qlhssv20.dao.TaiKhoanDAO;
import com.mycompany.qlhssv20.model.TaiKhoan;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class TaiKhoanView extends JPanel {

    private final TaiKhoanDAO dao = new TaiKhoanDAO();

    private final JTextField txtTenDangNhap = new JTextField(18);
    private final JPasswordField txtMatKhau = new JPasswordField(18);

    private final JComboBox<String> cboVaiTro =
            new JComboBox<>(new String[]{"Admin", "GiangVien", "SinhVien"});

    private final DefaultTableModel model = new DefaultTableModel(
            new String[]{"Tên đăng nhập", "Mật khẩu", "Vai trò"}, 0) {
        @Override
        public boolean isCellEditable(int row, int column) {
            return false;
        }
    };

    private final JTable table = new JTable(model);

    public TaiKhoanView() {
        setLayout(new BorderLayout(12, 12));
        setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        JLabel title = new JLabel("QUẢN LÝ TÀI KHOẢN");
        title.setFont(new Font("Arial", Font.BOLD, 22));
        title.setHorizontalAlignment(SwingConstants.CENTER);

        JPanel form = new JPanel(new GridLayout(3, 2, 10, 10));
        form.setBorder(BorderFactory.createTitledBorder("THÔNG TIN TÀI KHOẢN"));

        form.add(new JLabel("Tên đăng nhập:"));
        form.add(txtTenDangNhap);

        form.add(new JLabel("Mật khẩu:"));
        form.add(txtMatKhau);

        form.add(new JLabel("Vai trò:"));
        form.add(cboVaiTro);

        JButton btnThem = new JButton("Thêm");
        JButton btnSua = new JButton("Sửa");
        JButton btnXoa = new JButton("Xóa");
        JButton btnTaiLai = new JButton("Tải lại");
        JButton btnLamMoi = new JButton("Làm mới");

        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 8));
        buttons.add(btnThem);
        buttons.add(btnSua);
        buttons.add(btnXoa);
        buttons.add(btnTaiLai);
        buttons.add(btnLamMoi);

        JPanel top = new JPanel(new BorderLayout(8, 8));
        top.add(title, BorderLayout.NORTH);
        top.add(form, BorderLayout.CENTER);
        top.add(buttons, BorderLayout.SOUTH);

        add(top, BorderLayout.NORTH);
        add(new JScrollPane(table), BorderLayout.CENTER);

        btnThem.addActionListener(e -> them());
        btnSua.addActionListener(e -> sua());
        btnXoa.addActionListener(e -> xoa());
        btnTaiLai.addActionListener(e -> loadData());
        btnLamMoi.addActionListener(e -> lamMoi());

        table.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                hienThiDong();
            }
        });

        loadData();
    }

    private void them() {
        String ten = txtTenDangNhap.getText().trim();
        String matKhau = new String(txtMatKhau.getPassword());
        String vaiTro = (String) cboVaiTro.getSelectedItem();

        if (ten.isEmpty() || matKhau.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    "Vui lòng nhập tên đăng nhập và mật khẩu.");
            return;
        }

        if (dao.insert(new TaiKhoan(ten, matKhau, vaiTro))) {
            JOptionPane.showMessageDialog(this, "Thêm tài khoản thành công.");
            loadData();
            lamMoi();
        } else {
            JOptionPane.showMessageDialog(this,
                    "Thêm thất bại. Kiểm tra dữ liệu và tên cột SQL.");
        }
    }

    private void sua() {
        String ten = txtTenDangNhap.getText().trim();
        String matKhau = new String(txtMatKhau.getPassword());
        String vaiTro = (String) cboVaiTro.getSelectedItem();

        if (ten.isEmpty() || matKhau.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    "Vui lòng chọn tài khoản và nhập mật khẩu.");
            return;
        }

        if (dao.update(new TaiKhoan(ten, matKhau, vaiTro))) {
            JOptionPane.showMessageDialog(this, "Cập nhật thành công.");
            loadData();
            lamMoi();
        } else {
            JOptionPane.showMessageDialog(this,
                    "Cập nhật thất bại. Kiểm tra tài khoản cần sửa.");
        }
    }

    private void xoa() {
        String ten = txtTenDangNhap.getText().trim();

        if (ten.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Hãy chọn tài khoản cần xóa.");
            return;
        }

        int confirm = JOptionPane.showConfirmDialog(
                this,
                "Bạn có chắc muốn xóa tài khoản " + ten + "?",
                "Xác nhận xóa",
                JOptionPane.YES_NO_OPTION
        );

        if (confirm == JOptionPane.YES_OPTION) {
            if (dao.delete(ten)) {
                JOptionPane.showMessageDialog(this, "Xóa tài khoản thành công.");
                loadData();
                lamMoi();
            } else {
                JOptionPane.showMessageDialog(this, "Xóa tài khoản thất bại.");
            }
        }
    }

    private void loadData() {
        model.setRowCount(0);
        List<TaiKhoan> list = dao.getAll();

        for (TaiKhoan tk : list) {
            model.addRow(new Object[]{
                    tk.getTenDangNhap(),
                    "••••••••",
                    tk.getVaiTro()
            });
        }
    }

    private void hienThiDong() {
        int row = table.getSelectedRow();

        if (row >= 0) {
            txtTenDangNhap.setText(
                    String.valueOf(model.getValueAt(row, 0)));
            txtMatKhau.setText("");
            cboVaiTro.setSelectedItem(model.getValueAt(row, 2));
        }
    }

    private void lamMoi() {
        txtTenDangNhap.setText("");
        txtMatKhau.setText("");
        cboVaiTro.setSelectedIndex(0);
        table.clearSelection();
    }
}
