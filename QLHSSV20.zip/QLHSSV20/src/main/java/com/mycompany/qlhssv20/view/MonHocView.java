
package com.mycompany.qlhssv20.view;

import com.mycompany.qlhssv20.dao.MonHocDAO;
import com.mycompany.qlhssv20.model.MonHoc;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.SQLException;

public class MonHocView extends JPanel {

    private final Color NAVY = new Color(25, 42, 75);
    private final Color BLUE = new Color(49, 94, 168);
    private final Color BG = new Color(244, 247, 252);
    private final Color GREEN = new Color(32, 135, 83);
    private final Color RED = new Color(190, 55, 55);
    private final Color GRAY = new Color(100, 110, 125);

    private final MonHocDAO dao = new MonHocDAO();

    private JTextField txtMaMonHoc;
    private JTextField txtTenMonHoc;
    private JTextField txtSoTinChi;
    private JTextArea txtMoTa;
    private JTable tblMonHoc;
    private DefaultTableModel model;

    public MonHocView() {
        setLayout(new BorderLayout(12, 12));
        setBackground(BG);

        JLabel title = new JLabel("QUẢN LÝ MÔN HỌC");
        title.setFont(new Font("Arial", Font.BOLD, 20));
        title.setForeground(NAVY);

        JPanel form = new JPanel(new GridLayout(4, 2, 12, 10));
        form.setBackground(Color.WHITE);
        form.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createTitledBorder("THÔNG TIN MÔN HỌC"),
                BorderFactory.createEmptyBorder(12, 12, 12, 12)));

        txtMaMonHoc = new JTextField();
        txtTenMonHoc = new JTextField();
        txtSoTinChi = new JTextField();
        txtMoTa = new JTextArea(3, 20);
        txtMoTa.setLineWrap(true);
        txtMoTa.setWrapStyleWord(true);

        form.add(new JLabel("Mã môn học:"));
        form.add(txtMaMonHoc);
        form.add(new JLabel("Tên môn học:"));
        form.add(txtTenMonHoc);
        form.add(new JLabel("Số tín chỉ:"));
        form.add(txtSoTinChi);
        form.add(new JLabel("Mô tả:"));
        form.add(new JScrollPane(txtMoTa));

        JButton btnThem = new JButton("＋ Thêm");
        JButton btnSua = new JButton("✎ Sửa");
        JButton btnXoa = new JButton("✕ Xóa");
        JButton btnMoi = new JButton("Làm mới");
        JButton btnTaiLai = new JButton("↻ Tải danh sách");

        styleButton(btnThem, GREEN);
        styleButton(btnSua, BLUE);
        styleButton(btnXoa, RED);
        styleButton(btnMoi, GRAY);
        styleButton(btnTaiLai, NAVY);

        JPanel buttons = new JPanel(
                new FlowLayout(FlowLayout.LEFT, 8, 8));
        buttons.setBackground(BG);
        buttons.add(btnThem);
        buttons.add(btnSua);
        buttons.add(btnXoa);
        buttons.add(btnMoi);
        buttons.add(btnTaiLai);

        JPanel top = new JPanel();
        top.setLayout(new BoxLayout(top, BoxLayout.Y_AXIS));
        top.setBackground(BG);
        top.add(title);
        top.add(Box.createVerticalStrut(12));
        top.add(form);
        top.add(buttons);

        model = new DefaultTableModel(
                new String[]{"Mã môn học", "Tên môn học",
                    "Số tín chỉ", "Mô tả"}, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        tblMonHoc = new JTable(model);
        tblMonHoc.setRowHeight(28);
        tblMonHoc.setSelectionMode(
                ListSelectionModel.SINGLE_SELECTION);

        JScrollPane scroll = new JScrollPane(tblMonHoc);
        scroll.setBorder(BorderFactory.createTitledBorder(
                "DANH SÁCH MÔN HỌC"));

        add(top, BorderLayout.NORTH);
        add(scroll, BorderLayout.CENTER);

        btnThem.addActionListener(e -> themMonHoc());
        btnSua.addActionListener(e -> suaMonHoc());
        btnXoa.addActionListener(e -> xoaMonHoc());
        btnMoi.addActionListener(e -> lamMoi());
        btnTaiLai.addActionListener(e -> loadData());

        tblMonHoc.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                hienThiThongTin();
            }
        });

        loadData();
    }

    private void styleButton(JButton button, Color color) {
        button.setFont(new Font("Arial", Font.BOLD, 12));
        button.setForeground(Color.WHITE);
        button.setBackground(color);
        button.setFocusPainted(false);
        button.setBorderPainted(false);
        button.setPreferredSize(new Dimension(140, 36));
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
    }

    private void loadData() {
        try {
            model.setRowCount(0);

            for (MonHoc mon : dao.getAll()) {
                model.addRow(new Object[]{
                    mon.getMaMonHoc(),
                    mon.getTenMonHoc(),
                    mon.getSoTinChi(),
                    mon.getMoTa()
                });
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this,
                    "Không tải được danh sách môn học:\n"
                    + ex.getMessage(),
                    "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void themMonHoc() {
        String ma = txtMaMonHoc.getText().trim();
        String ten = txtTenMonHoc.getText().trim();
        String moTa = txtMoTa.getText().trim();

        if (ma.isEmpty() || ten.isEmpty()
                || txtSoTinChi.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    "Vui lòng nhập mã môn, tên môn và số tín chỉ.");
            return;
        }

        int tinChi;
        try {
            tinChi = Integer.parseInt(txtSoTinChi.getText().trim());
            if (tinChi <= 0) {
                JOptionPane.showMessageDialog(this,
                        "Số tín chỉ phải lớn hơn 0.");
                return;
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this,
                    "Số tín chỉ phải là số nguyên.");
            return;
        }

        try {
            if (dao.insert(new MonHoc(ma, ten, tinChi, moTa))) {
                JOptionPane.showMessageDialog(this,
                        "Thêm môn học thành công!");
                loadData();
                lamMoi();
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this,
                    "Không thêm được môn học:\n" + ex.getMessage(),
                    "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void suaMonHoc() {
        String ma = txtMaMonHoc.getText().trim();
        String ten = txtTenMonHoc.getText().trim();
        String moTa = txtMoTa.getText().trim();

        if (ma.isEmpty() || ten.isEmpty()
                || txtSoTinChi.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    "Hãy chọn môn học và nhập đủ thông tin.");
            return;
        }

        int tinChi;
        try {
            tinChi = Integer.parseInt(txtSoTinChi.getText().trim());
            if (tinChi <= 0) {
                JOptionPane.showMessageDialog(this,
                        "Số tín chỉ phải lớn hơn 0.");
                return;
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this,
                    "Số tín chỉ phải là số nguyên.");
            return;
        }

        try {
            if (dao.update(new MonHoc(ma, ten, tinChi, moTa))) {
                JOptionPane.showMessageDialog(this,
                        "Cập nhật môn học thành công!");
                loadData();
                lamMoi();
            } else {
                JOptionPane.showMessageDialog(this,
                        "Không tìm thấy môn học cần sửa.");
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this,
                    "Không sửa được môn học:\n" + ex.getMessage(),
                    "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void xoaMonHoc() {
        String ma = txtMaMonHoc.getText().trim();

        if (ma.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    "Hãy chọn môn học cần xóa.");
            return;
        }

        int confirm = JOptionPane.showConfirmDialog(this,
                "Bạn có chắc muốn xóa môn học " + ma + "?",
                "Xác nhận xóa", JOptionPane.YES_NO_OPTION);

        if (confirm != JOptionPane.YES_OPTION) {
            return;
        }

        try {
            if (dao.delete(ma)) {
                JOptionPane.showMessageDialog(this,
                        "Xóa môn học thành công!");
                loadData();
                lamMoi();
            } else {
                JOptionPane.showMessageDialog(this,
                        "Không tìm thấy môn học cần xóa.");
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this,
                    "Không xóa được môn học:\n" + ex.getMessage(),
                    "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void hienThiThongTin() {
        int row = tblMonHoc.getSelectedRow();

        if (row >= 0) {
            txtMaMonHoc.setText(
                    String.valueOf(model.getValueAt(row, 0)));
            txtTenMonHoc.setText(
                    String.valueOf(model.getValueAt(row, 1)));
            txtSoTinChi.setText(
                    String.valueOf(model.getValueAt(row, 2)));

            Object moTa = model.getValueAt(row, 3);
            txtMoTa.setText(moTa == null ? "" : moTa.toString());

            txtMaMonHoc.setEditable(false);
        }
    }

    private void lamMoi() {
        txtMaMonHoc.setText("");
        txtTenMonHoc.setText("");
        txtSoTinChi.setText("");
        txtMoTa.setText("");
        txtMaMonHoc.setEditable(true);
        tblMonHoc.clearSelection();
    }
}
