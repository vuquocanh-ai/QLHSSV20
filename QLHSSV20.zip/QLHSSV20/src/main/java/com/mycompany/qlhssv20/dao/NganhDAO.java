
package com.mycompany.qlhssv20.dao;

import com.mycompany.qlhssv20.model.DBConnection;
import com.mycompany.qlhssv20.model.Nganh;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class NganhDAO {

    // Lấy toàn bộ danh sách ngành
    public List<Nganh> getAll() throws SQLException {
        List<Nganh> danhSach = new ArrayList<>();

        String sql = "SELECT MaNganh, TenNganh, MaKhoa, MoTa "
                   + "FROM dbo.Nganh";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                Nganh nganh = new Nganh(
                    rs.getString("MaNganh"),
                    rs.getString("TenNganh"),
                    rs.getString("MaKhoa"),
                    rs.getString("MoTa")
                );

                danhSach.add(nganh);
            }
        }

        return danhSach;
    }

    // Thêm ngành
    public boolean insert(Nganh nganh) throws SQLException {
        String sql = "INSERT INTO dbo.Nganh "
                   + "(MaNganh, TenNganh, MaKhoa, MoTa) "
                   + "VALUES (?, ?, ?, ?)";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, nganh.getMaNganh());
            ps.setString(2, nganh.getTenNganh());
            ps.setString(3, nganh.getMaKhoa());
            ps.setString(4, nganh.getMoTa());

            return ps.executeUpdate() > 0;
        }
    }

    // Sửa ngành
    public boolean update(Nganh nganh) throws SQLException {
        String sql = "UPDATE dbo.Nganh "
                   + "SET TenNganh = ?, MaKhoa = ?, MoTa = ? "
                   + "WHERE MaNganh = ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, nganh.getTenNganh());
            ps.setString(2, nganh.getMaKhoa());
            ps.setString(3, nganh.getMoTa());
            ps.setString(4, nganh.getMaNganh());

            return ps.executeUpdate() > 0;
        }
    }

    // Xóa ngành
    public boolean delete(String maNganh) throws SQLException {
        String sql = "DELETE FROM dbo.Nganh WHERE MaNganh = ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, maNganh);

            return ps.executeUpdate() > 0;
        }
    }
}
