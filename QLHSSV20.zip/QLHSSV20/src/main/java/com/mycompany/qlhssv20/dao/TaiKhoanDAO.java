
package com.mycompany.qlhssv20.dao;

import com.mycompany.qlhssv20.model.DBConnection;
import com.mycompany.qlhssv20.model.TaiKhoan;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class TaiKhoanDAO {

    public List<TaiKhoan> getAll() {
        List<TaiKhoan> list = new ArrayList<>();

        String sql = "SELECT TenDangNhap, MatKhau, VaiTro FROM TaiKhoan";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                list.add(new TaiKhoan(
                    rs.getString("TenDangNhap"),
                    rs.getString("MatKhau"),
                    rs.getString("VaiTro")
                ));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return list;
    }

    public boolean insert(TaiKhoan tk) {
        String sql = "INSERT INTO TaiKhoan "
                   + "(TenDangNhap, MatKhau, VaiTro) VALUES (?, ?, ?)";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, tk.getTenDangNhap());
            ps.setString(2, tk.getMatKhau());
            ps.setString(3, tk.getVaiTro());

            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean update(TaiKhoan tk) {
        String sql = "UPDATE TaiKhoan SET MatKhau = ?, VaiTro = ? "
                   + "WHERE TenDangNhap = ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, tk.getMatKhau());
            ps.setString(2, tk.getVaiTro());
            ps.setString(3, tk.getTenDangNhap());

            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean delete(String tenDangNhap) {
        String sql = "DELETE FROM TaiKhoan WHERE TenDangNhap = ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, tenDangNhap);
            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    
public com.mycompany.qlhssv20.model.TaiKhoan dangNhap(
        String tenDangNhap, String matKhau) {

    String sql = """
        SELECT TenDangNhap, MatKhau, VaiTro
        FROM TaiKhoan
        WHERE TenDangNhap = ? AND MatKhau = ?
        """;

    try (
        java.sql.Connection conn =
            com.mycompany.qlhssv20.model.DBConnection.getConnection();
        java.sql.PreparedStatement ps = conn.prepareStatement(sql)
    ) {
        ps.setString(1, tenDangNhap);
        ps.setString(2, matKhau);

        try (java.sql.ResultSet rs = ps.executeQuery()) {
            if (rs.next()) {
                return new com.mycompany.qlhssv20.model.TaiKhoan(
                    rs.getString("TenDangNhap"),
                    rs.getString("MatKhau"),
                    rs.getString("VaiTro")
                );
            }
        }
    } catch (java.sql.SQLException e) {
        javax.swing.JOptionPane.showMessageDialog(
            null,
            "Lỗi đăng nhập: " + e.getMessage(),
            "Lỗi",
            javax.swing.JOptionPane.ERROR_MESSAGE
        );
    }

    return null;
}

}
