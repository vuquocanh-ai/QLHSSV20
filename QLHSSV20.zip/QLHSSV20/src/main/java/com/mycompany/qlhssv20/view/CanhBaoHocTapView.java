
package com.mycompany.qlhssv20.view;

import com.mycompany.qlhssv20.dao.CanhBaoHocTapDAO;
import com.mycompany.qlhssv20.model.CanhBaoHocTap;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.SQLException;

public class CanhBaoHocTapView extends JPanel {

    private final CanhBaoHocTapDAO dao = new CanhBaoHocTapDAO();

    private final JComboBox<String> cboLoai = new JComboBox<>(
            new String[]{
                "Tất cả cảnh báo",
                "Điểm tổng kết dưới 5",
                "Chưa có điểm tổng kết"
            });

    private final DefaultTableModel model = new DefaultTableModel(
            new String[]{
                "Mã SV", "Họ tên", "Lớp", "Mã môn",
                "Tên môn", "Điểm tổng kết", "Nội dung cảnh báo"
            }, 0) {
        @Override
        public boolean isCellEditable(int row, int column) {
            return false;
        }
    };

    private final JTable table = new JTable(model);

    public CanhBaoHocTapView() {
        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        JLabel title = new JLabel("CẢNH BÁO HỌC TẬP");
        title.setFont(new Font("Arial", Font.BOLD, 22));

        JButton btnLoc = new JButton("Lọc cảnh báo");
        JButton btnTaiLai = new JButton("Tải lại");

        JPanel top = new JPanel(new FlowLayout(FlowLayout.LEFT));
        top.add(new JLabel("Loại cảnh báo:"));
        top.add(cboLoai);
        top.add(btnLoc);
        top.add(btnTaiLai);

        JPanel north = new JPanel(new BorderLayout());
        north.add(title, BorderLayout.NORTH);
        north.add(top, BorderLayout.SOUTH);

        add(north, BorderLayout.NORTH);
        add(new JScrollPane(table), BorderLayout.CENTER);

        btnLoc.addActionListener(e -> taiDuLieu());
        btnTaiLai.addActionListener(e -> taiDuLieu());

        taiDuLieu();
    }

    private void taiDuLieu() {
        try {
            String loai;

            switch (cboLoai.getSelectedIndex()) {
                case 1:
                    loai = "DIEM_THAP";
                    break;
                case 2:
                    loai = "CHUA_CO_DIEM";
                    break;
                default:
                    loai = "TAT_CA";
            }

            model.setRowCount(0);

            for (CanhBaoHocTap cb : dao.getCanhBao(loai)) {
                model.addRow(new Object[]{
                    cb.getMaSV(),
                    cb.getHoTen(),
                    cb.getLop(),
                    cb.getMaMonHoc(),
                    cb.getTenMonHoc(),
                    cb.getDiemTongKet() == null
                            ? "Chưa có" : cb.getDiemTongKet(),
                    cb.getNoiDungCanhBao()
                });
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this,
                    "Lỗi tải cảnh báo: " + ex.getMessage(),
                    "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    }
}
