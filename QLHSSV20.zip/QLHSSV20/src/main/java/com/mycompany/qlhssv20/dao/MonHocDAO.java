
package com.mycompany.qlhssv20.dao;

import com.mycompany.qlhssv20.model.DBConnection;
import com.mycompany.qlhssv20.model.MonHoc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class MonHocDAO {

    // Lấy danh sách môn học
    public List<MonHoc> getAll() throws SQLException {
        List<MonHoc> danhSach = new ArrayList<>();

        String sql = "SELECT MaMonHoc, TenMonHoc, SoTinChi, MoTa "
                   + "FROM dbo.MonHoc ORDER BY MaMonHoc";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                MonHoc mon = new MonHoc(
                    rs.getString("MaMonHoc"),
                    rs.getString("TenMonHoc"),
                    rs.getInt("SoTinChi"),
                    rs.getString("MoTa")
                );
                danhSach.add(mon);
            }
        }

        return danhSach;
    }

    // Thêm môn học
    public boolean insert(MonHoc mon) throws SQLException {
        String sql = "INSERT INTO dbo.MonHoc "
                   + "(MaMonHoc, TenMonHoc, SoTinChi, MoTa) "
                   + "VALUES (?, ?, ?, ?)";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, mon.getMaMonHoc());
            ps.setString(2, mon.getTenMonHoc());
            ps.setInt(3, mon.getSoTinChi());
            ps.setString(4, mon.getMoTa());

            return ps.executeUpdate() > 0;
        }
    }

    // Sửa môn học
    public boolean update(MonHoc mon) throws SQLException {
        String sql = "UPDATE dbo.MonHoc "
                   + "SET TenMonHoc = ?, SoTinChi = ?, MoTa = ? "
                   + "WHERE MaMonHoc = ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, mon.getTenMonHoc());
            ps.setInt(2, mon.getSoTinChi());
            ps.setString(3, mon.getMoTa());
            ps.setString(4, mon.getMaMonHoc());

            return ps.executeUpdate() > 0;
        }
    }

    // Xóa môn học
    public boolean delete(String maMonHoc) throws SQLException {
        String sql = "DELETE FROM dbo.MonHoc WHERE MaMonHoc = ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, maMonHoc);

            return ps.executeUpdate() > 0;
        }
    }
}
