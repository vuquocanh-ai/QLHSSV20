
package com.mycompany.qlhssv20.model;

public class Diem {
    private String maSV;
    private String maMonHoc;
    private Double diemQuaTrinh;
    private Double diemThi;
    private Double diemTongKet;

    public Diem() {
    }

    public Diem(String maSV, String maMonHoc,
                Double diemQuaTrinh, Double diemThi,
                Double diemTongKet) {
        this.maSV = maSV;
        this.maMonHoc = maMonHoc;
        this.diemQuaTrinh = diemQuaTrinh;
        this.diemThi = diemThi;
        this.diemTongKet = diemTongKet;
    }

    public String getMaSV() {
        return maSV;
    }

    public void setMaSV(String maSV) {
        this.maSV = maSV;
    }

    public String getMaMonHoc() {
        return maMonHoc;
    }

    public void setMaMonHoc(String maMonHoc) {
        this.maMonHoc = maMonHoc;
    }

    public Double getDiemQuaTrinh() {
        return diemQuaTrinh;
    }

    public void setDiemQuaTrinh(Double diemQuaTrinh) {
        this.diemQuaTrinh = diemQuaTrinh;
    }

    public Double getDiemThi() {
        return diemThi;
    }

    public void setDiemThi(Double diemThi) {
        this.diemThi = diemThi;
    }

    public Double getDiemTongKet() {
        return diemTongKet;
    }

    public void setDiemTongKet(Double diemTongKet) {
        this.diemTongKet = diemTongKet;
    }
}
