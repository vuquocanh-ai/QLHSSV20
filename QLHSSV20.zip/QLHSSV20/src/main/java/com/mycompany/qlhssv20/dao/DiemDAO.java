
package com.mycompany.qlhssv20.dao;

import com.mycompany.qlhssv20.model.DBConnection;
import com.mycompany.qlhssv20.model.Diem;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class DiemDAO {

    public List<Diem> getAll() {
        List<Diem> list = new ArrayList<>();

        String sql = "SELECT MaSV, MaMonHoc, DiemQuaTrinh, "
                   + "DiemThi, DiemTongKet FROM Diem";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                Diem d = new Diem(
                    rs.getString("MaSV"),
                    rs.getString("MaMonHoc"),
                    getNullableDouble(rs, "DiemQuaTrinh"),
                    getNullableDouble(rs, "DiemThi"),
                    getNullableDouble(rs, "DiemTongKet")
                );
                list.add(d);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return list;
    }

    private Double getNullableDouble(ResultSet rs, String column)
            throws SQLException {
        double value = rs.getDouble(column);
        return rs.wasNull() ? null : value;
    }

    public boolean insert(Diem d) {
        String sql = "INSERT INTO Diem "
                   + "(MaSV, MaMonHoc, DiemQuaTrinh, DiemThi, DiemTongKet) "
                   + "VALUES (?, ?, ?, ?, ?)";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, d.getMaSV());
            ps.setString(2, d.getMaMonHoc());
            setNullableDouble(ps, 3, d.getDiemQuaTrinh());
            setNullableDouble(ps, 4, d.getDiemThi());
            setNullableDouble(ps, 5, d.getDiemTongKet());

            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean update(Diem d) {
        String sql = "UPDATE Diem SET DiemQuaTrinh = ?, DiemThi = ?, "
                   + "DiemTongKet = ? WHERE MaSV = ? AND MaMonHoc = ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            setNullableDouble(ps, 1, d.getDiemQuaTrinh());
            setNullableDouble(ps, 2, d.getDiemThi());
            setNullableDouble(ps, 3, d.getDiemTongKet());
            ps.setString(4, d.getMaSV());
            ps.setString(5, d.getMaMonHoc());

            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean delete(String maSV, String maMonHoc) {
        String sql = "DELETE FROM Diem WHERE MaSV = ? AND MaMonHoc = ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, maSV);
            ps.setString(2, maMonHoc);

            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    private void setNullableDouble(PreparedStatement ps, int index,
                                   Double value) throws SQLException {
        if (value == null) {
            ps.setNull(index, Types.DECIMAL);
        } else {
            ps.setDouble(index, value);
        }
    }
}
