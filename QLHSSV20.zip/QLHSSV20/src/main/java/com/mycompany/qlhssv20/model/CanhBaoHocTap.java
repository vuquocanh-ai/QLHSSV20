
package com.mycompany.qlhssv20.model;

public class CanhBaoHocTap {

    private String maSV;
    private String hoTen;
    private String lop;
    private String maMonHoc;
    private String tenMonHoc;
    private Double diemTongKet;
    private String noiDungCanhBao;

    public CanhBaoHocTap(String maSV, String hoTen, String lop,
                         String maMonHoc, String tenMonHoc,
                         Double diemTongKet, String noiDungCanhBao) {
        this.maSV = maSV;
        this.hoTen = hoTen;
        this.lop = lop;
        this.maMonHoc = maMonHoc;
        this.tenMonHoc = tenMonHoc;
        this.diemTongKet = diemTongKet;
        this.noiDungCanhBao = noiDungCanhBao;
    }

    public String getMaSV() {
        return maSV;
    }

    public String getHoTen() {
        return hoTen;
    }

    public String getLop() {
        return lop;
    }

    public String getMaMonHoc() {
        return maMonHoc;
    }

    public String getTenMonHoc() {
        return tenMonHoc;
    }

    public Double getDiemTongKet() {
        return diemTongKet;
    }

    public String getNoiDungCanhBao() {
        return noiDungCanhBao;
    }
}
