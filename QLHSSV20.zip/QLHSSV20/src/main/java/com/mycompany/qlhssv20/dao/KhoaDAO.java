
package com.mycompany.qlhssv20.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import com.mycompany.qlhssv20.model.Khoa;
import com.mycompany.qlhssv20.model.DBConnection;

public class KhoaDAO {

    // Lấy danh sách khoa
    public List<Khoa> getAll() throws SQLException {
        List<Khoa> danhSach = new ArrayList<>();

        String sql = "SELECT MaKhoa, TenKhoa, MoTa FROM dbo.Khoa";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                Khoa khoa = new Khoa(
                    rs.getString("MaKhoa"),
                    rs.getString("TenKhoa"),
                    rs.getString("MoTa")
                );

                danhSach.add(khoa);
            }
        }

        return danhSach;
    }

    // Thêm khoa
    public boolean insert(Khoa khoa) throws SQLException {
        String sql = "INSERT INTO dbo.Khoa (MaKhoa, TenKhoa, MoTa) "
                   + "VALUES (?, ?, ?)";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, khoa.getMaKhoa());
            ps.setString(2, khoa.getTenKhoa());
            ps.setString(3, khoa.getMoTa());

            return ps.executeUpdate() > 0;
        }
    }

    // Sửa khoa
    public boolean update(Khoa khoa) throws SQLException {
        String sql = "UPDATE dbo.Khoa "
                   + "SET TenKhoa = ?, MoTa = ? WHERE MaKhoa = ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, khoa.getTenKhoa());
            ps.setString(2, khoa.getMoTa());
            ps.setString(3, khoa.getMaKhoa());

            return ps.executeUpdate() > 0;
        }
    }

    // Xóa khoa
    public boolean delete(String maKhoa) throws SQLException {
        String sql = "DELETE FROM dbo.Khoa WHERE MaKhoa = ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, maKhoa);

            return ps.executeUpdate() > 0;
        }
    }
  
}
