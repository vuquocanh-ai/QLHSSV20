
package com.mycompany.qlhssv20.view;

import com.mycompany.qlhssv20.dao.KhoaDAO;
import com.mycompany.qlhssv20.dao.NganhDAO;
import com.mycompany.qlhssv20.model.Khoa;
import com.mycompany.qlhssv20.model.Nganh;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.SQLException;
import java.util.List;

public class NganhView extends JPanel {

    private final Color NAVY = new Color(25, 42, 75);
    private final Color BLUE = new Color(49, 94, 168);
    private final Color BG = new Color(244, 247, 252);
    private final Color GREEN = new Color(32, 135, 83);
    private final Color RED = new Color(190, 55, 55);
    private final Color GRAY = new Color(100, 110, 125);

    private final NganhDAO nganhDAO = new NganhDAO();
    private final KhoaDAO khoaDAO = new KhoaDAO();

    private JTextField txtMaNganh;
    private JTextField txtTenNganh;
    private JComboBox<Khoa> cboKhoa;
    private JTextArea txtMoTa;
    private JTable tblNganh;
    private DefaultTableModel model;

    public NganhView() {
        setLayout(new BorderLayout(12, 12));
        setBackground(BG);

        JLabel title = new JLabel("QUẢN LÝ NGÀNH HỌC");
        title.setFont(new Font("Arial", Font.BOLD, 20));
        title.setForeground(NAVY);

        JPanel form = new JPanel(new GridLayout(4, 2, 12, 10));
        form.setBackground(Color.WHITE);
        form.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createTitledBorder("THÔNG TIN NGÀNH"),
                BorderFactory.createEmptyBorder(12, 12, 12, 12)));

        txtMaNganh = new JTextField();
        txtTenNganh = new JTextField();
        cboKhoa = new JComboBox<>();
        txtMoTa = new JTextArea(3, 20);
        txtMoTa.setLineWrap(true);
        txtMoTa.setWrapStyleWord(true);

        form.add(new JLabel("Mã ngành:"));
        form.add(txtMaNganh);
        form.add(new JLabel("Tên ngành:"));
        form.add(txtTenNganh);
        form.add(new JLabel("Khoa quản lý:"));
        form.add(cboKhoa);
        form.add(new JLabel("Mô tả:"));
        form.add(new JScrollPane(txtMoTa));

        JButton btnThem = new JButton("＋ Thêm");
        JButton btnSua = new JButton("✎ Sửa");
        JButton btnXoa = new JButton("✕ Xóa");
        JButton btnMoi = new JButton("Làm mới");
        JButton btnTaiLai = new JButton("↻ Tải danh sách");

        styleButton(btnThem, GREEN);
        styleButton(btnSua, BLUE);
        styleButton(btnXoa, RED);
        styleButton(btnMoi, GRAY);
        styleButton(btnTaiLai, NAVY);

        JPanel buttons = new JPanel(
                new FlowLayout(FlowLayout.LEFT, 8, 8));
        buttons.setBackground(BG);
        buttons.add(btnThem);
        buttons.add(btnSua);
        buttons.add(btnXoa);
        buttons.add(btnMoi);
        buttons.add(btnTaiLai);

        JPanel top = new JPanel();
        top.setLayout(new BoxLayout(top, BoxLayout.Y_AXIS));
        top.setBackground(BG);
        top.add(title);
        top.add(Box.createVerticalStrut(12));
        top.add(form);
        top.add(buttons);

        model = new DefaultTableModel(
                new String[]{"Mã ngành", "Tên ngành",
                    "Mã khoa", "Tên khoa", "Mô tả"}, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        tblNganh = new JTable(model);
        tblNganh.setRowHeight(28);
        tblNganh.setSelectionMode(
                ListSelectionModel.SINGLE_SELECTION);

        JScrollPane scroll = new JScrollPane(tblNganh);
        scroll.setBorder(BorderFactory.createTitledBorder(
                "DANH SÁCH NGÀNH"));

        add(top, BorderLayout.NORTH);
        add(scroll, BorderLayout.CENTER);

        btnThem.addActionListener(e -> themNganh());
        btnSua.addActionListener(e -> suaNganh());
        btnXoa.addActionListener(e -> xoaNganh());
        btnMoi.addActionListener(e -> lamMoi());
        btnTaiLai.addActionListener(e -> {
            loadKhoa();
            loadNganh();
        });

        tblNganh.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                hienThiThongTin();
            }
        });

        loadKhoa();
        loadNganh();
    }

    private void styleButton(JButton button, Color color) {
        button.setFont(new Font("Arial", Font.BOLD, 12));
        button.setForeground(Color.WHITE);
        button.setBackground(color);
        button.setFocusPainted(false);
        button.setBorderPainted(false);
        button.setPreferredSize(new Dimension(140, 36));
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
    }

    private void loadKhoa() {
        try {
            String maDangChon = null;
            Object selected = cboKhoa.getSelectedItem();

            if (selected instanceof Khoa) {
                maDangChon = ((Khoa) selected).getMaKhoa();
            }

            cboKhoa.removeAllItems();

            List<Khoa> danhSach = khoaDAO.getAll();
            for (Khoa khoa : danhSach) {
                cboKhoa.addItem(khoa);
            }

            if (maDangChon != null) {
                for (int i = 0; i < cboKhoa.getItemCount(); i++) {
                    Khoa khoa = cboKhoa.getItemAt(i);
                    if (khoa.getMaKhoa().equals(maDangChon)) {
                        cboKhoa.setSelectedIndex(i);
                        break;
                    }
                }
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this,
                    "Không tải được danh sách khoa:\n"
                    + ex.getMessage(),
                    "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void loadNganh() {
        try {
            model.setRowCount(0);

            String sql = "SELECT n.MaNganh, n.TenNganh, "
                       + "n.MaKhoa, k.TenKhoa, n.MoTa "
                       + "FROM dbo.Nganh n "
                       + "LEFT JOIN dbo.Khoa k "
                       + "ON n.MaKhoa = k.MaKhoa "
                       + "ORDER BY n.MaNganh";

            // Dùng DAO để lấy dữ liệu ngành và tên khoa
            // Phần truy vấn này sẽ được bổ sung vào DAO ở bước sau.
            for (Nganh nganh : nganhDAO.getAll()) {
                model.addRow(new Object[]{
                    nganh.getMaNganh(),
                    nganh.getTenNganh(),
                    nganh.getMaKhoa(),
                    timTenKhoa(nganh.getMaKhoa()),
                    nganh.getMoTa()
                });
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this,
                    "Không tải được danh sách ngành:\n"
                    + ex.getMessage(),
                    "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    }

    private String timTenKhoa(String maKhoa) {
        for (int i = 0; i < cboKhoa.getItemCount(); i++) {
            Khoa khoa = cboKhoa.getItemAt(i);
            if (khoa.getMaKhoa().equals(maKhoa)) {
                return khoa.getTenKhoa();
            }
        }
        return "";
    }

    private Khoa layKhoaDangChon() {
        Object selected = cboKhoa.getSelectedItem();
        return selected instanceof Khoa ? (Khoa) selected : null;
    }

    private void themNganh() {
        String ma = txtMaNganh.getText().trim();
        String ten = txtTenNganh.getText().trim();
        String moTa = txtMoTa.getText().trim();
        Khoa khoa = layKhoaDangChon();

        if (ma.isEmpty() || ten.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    "Vui lòng nhập mã ngành và tên ngành.");
            return;
        }

        if (khoa == null) {
            JOptionPane.showMessageDialog(this,
                    "Bạn cần tạo ít nhất một khoa trước.");
            return;
        }

        try {
            if (nganhDAO.insert(new Nganh(
                    ma, ten, khoa.getMaKhoa(), moTa))) {
                JOptionPane.showMessageDialog(this,
                        "Thêm ngành thành công!");
                loadNganh();
                lamMoi();
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this,
                    "Không thêm được ngành:\n" + ex.getMessage(),
                    "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void suaNganh() {
        String ma = txtMaNganh.getText().trim();
        String ten = txtTenNganh.getText().trim();
        String moTa = txtMoTa.getText().trim();
        Khoa khoa = layKhoaDangChon();

        if (ma.isEmpty() || ten.isEmpty() || khoa == null) {
            JOptionPane.showMessageDialog(this,
                    "Hãy chọn ngành và nhập đủ thông tin.");
            return;
        }

        try {
            if (nganhDAO.update(new Nganh(
                    ma, ten, khoa.getMaKhoa(), moTa))) {
                JOptionPane.showMessageDialog(this,
                        "Cập nhật ngành thành công!");
                loadNganh();
                lamMoi();
            } else {
                JOptionPane.showMessageDialog(this,
                        "Không tìm thấy ngành cần sửa.");
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this,
                    "Không sửa được ngành:\n" + ex.getMessage(),
                    "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void xoaNganh() {
        String ma = txtMaNganh.getText().trim();

        if (ma.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    "Hãy chọn ngành cần xóa.");
            return;
        }

        int confirm = JOptionPane.showConfirmDialog(this,
                "Bạn có chắc muốn xóa ngành " + ma + "?",
                "Xác nhận xóa", JOptionPane.YES_NO_OPTION);

        if (confirm != JOptionPane.YES_OPTION) {
            return;
        }

        try {
            if (nganhDAO.delete(ma)) {
                JOptionPane.showMessageDialog(this,
                        "Xóa ngành thành công!");
                loadNganh();
                lamMoi();
            } else {
                JOptionPane.showMessageDialog(this,
                        "Không tìm thấy ngành cần xóa.");
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this,
                    "Không xóa được ngành:\n" + ex.getMessage(),
                    "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void hienThiThongTin() {
        int row = tblNganh.getSelectedRow();

        if (row >= 0) {
            txtMaNganh.setText(
                    String.valueOf(model.getValueAt(row, 0)));
            txtTenNganh.setText(
                    String.valueOf(model.getValueAt(row, 1)));

            String maKhoa = String.valueOf(
                    model.getValueAt(row, 2));

            for (int i = 0; i < cboKhoa.getItemCount(); i++) {
                Khoa khoa = cboKhoa.getItemAt(i);
                if (khoa.getMaKhoa().equals(maKhoa)) {
                    cboKhoa.setSelectedIndex(i);
                    break;
                }
            }

            Object moTa = model.getValueAt(row, 4);
            txtMoTa.setText(moTa == null ? "" : moTa.toString());
            txtMaNganh.setEditable(false);
        }
    }

    private void lamMoi() {
        txtMaNganh.setText("");
        txtTenNganh.setText("");
        txtMoTa.setText("");
        txtMaNganh.setEditable(true);
        tblNganh.clearSelection();
        if (cboKhoa.getItemCount() > 0) {
            cboKhoa.setSelectedIndex(0);
        }
    }
}
