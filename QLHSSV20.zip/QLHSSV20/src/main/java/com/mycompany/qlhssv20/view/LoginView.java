
package com.mycompany.qlhssv20.view;

import com.mycompany.qlhssv20.dao.TaiKhoanDAO;
import com.mycompany.qlhssv20.model.TaiKhoan;
import com.mycompany.qlhssv20.controller.SinhVienController;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;

public class LoginView extends JFrame {

    private JTextField txtTenDangNhap;
    private JPasswordField txtMatKhau;
    private JButton btnDangNhap;
    private JCheckBox chkHienMatKhau;

    private final Color xanhDam = new Color(16, 28, 54);
    private final Color xanhDuong = new Color(37, 99, 235);

    public LoginView() {
        setTitle("Đăng nhập - Student Portal");
        setSize(900, 560);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);

        JPanel root = new JPanel(new GridLayout(1, 2));
        root.add(createWelcomePanel());
        root.add(createLoginPanel());

        setContentPane(root);
    }

    private JPanel createWelcomePanel() {
        GradientPanel panel = new GradientPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBorder(new EmptyBorder(55, 40, 40, 35));

        JLabel logo = new JLabel("  STUDENT PORTAL");
        logo.setFont(new Font("Arial", Font.BOLD, 23));
        logo.setForeground(Color.WHITE);
        logo.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel icon = new JLabel("🎓");
        icon.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 66));
        icon.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel title = new JLabel(
            "<html>Quản lý hồ sơ<br>sinh viên</html>"
        );
        title.setFont(new Font("Arial", Font.BOLD, 30));
        title.setForeground(Color.WHITE);
        title.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel description = new JLabel(
            "<html>Quản lý thông tin, môn học, điểm số<br>"
            + "và kết quả học tập trên một hệ thống.</html>"
        );
        description.setFont(new Font("Arial", Font.PLAIN, 14));
        description.setForeground(new Color(205, 218, 240));
        description.setAlignmentX(Component.LEFT_ALIGNMENT);

        panel.add(logo);
        panel.add(Box.createVerticalStrut(80));
        panel.add(icon);
        panel.add(Box.createVerticalStrut(20));
        panel.add(title);
        panel.add(Box.createVerticalStrut(18));
        panel.add(description);
        panel.add(Box.createVerticalGlue());

        JLabel footer = new JLabel("STUDENT MANAGEMENT SYSTEM");
        footer.setFont(new Font("Arial", Font.PLAIN, 10));
        footer.setForeground(new Color(170, 190, 220));
        footer.setAlignmentX(Component.LEFT_ALIGNMENT);
        panel.add(footer);

        return panel;
    }

    private JPanel createLoginPanel() {
        JPanel panel = new JPanel();
        panel.setBackground(Color.WHITE);
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBorder(new EmptyBorder(65, 45, 35, 45));

        JLabel title = new JLabel("Chào mừng trở lại!");
        title.setFont(new Font("Arial", Font.BOLD, 25));
        title.setForeground(new Color(23, 37, 84));
        title.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel subtitle = new JLabel("Đăng nhập để tiếp tục");
        subtitle.setFont(new Font("Arial", Font.PLAIN, 13));
        subtitle.setForeground(new Color(100, 116, 139));
        subtitle.setAlignmentX(Component.LEFT_ALIGNMENT);

        panel.add(title);
        panel.add(Box.createVerticalStrut(10));
        panel.add(subtitle);
        panel.add(Box.createVerticalStrut(35));

        panel.add(createLabel("TÊN ĐĂNG NHẬP"));
        txtTenDangNhap = new JTextField();
        styleTextField(txtTenDangNhap);
        panel.add(txtTenDangNhap);

        panel.add(Box.createVerticalStrut(22));
        panel.add(createLabel("MẬT KHẨU"));

        txtMatKhau = new JPasswordField();
        styleTextField(txtMatKhau);
        panel.add(txtMatKhau);

        chkHienMatKhau = new JCheckBox("Hiện mật khẩu");
        chkHienMatKhau.setFont(new Font("Arial", Font.PLAIN, 12));
        chkHienMatKhau.setBackground(Color.WHITE);
        chkHienMatKhau.setForeground(new Color(71, 85, 105));
        chkHienMatKhau.setAlignmentX(Component.LEFT_ALIGNMENT);
        chkHienMatKhau.setFocusPainted(false);

        chkHienMatKhau.addActionListener(e -> {
            txtMatKhau.setEchoChar(
                chkHienMatKhau.isSelected() ? '\0' : '\u2022'
            );
        });

        panel.add(Box.createVerticalStrut(10));
        panel.add(chkHienMatKhau);
        panel.add(Box.createVerticalStrut(25));

        btnDangNhap = new JButton("ĐĂNG NHẬP");
        btnDangNhap.setFont(new Font("Arial", Font.BOLD, 14));
        btnDangNhap.setForeground(Color.WHITE);
        btnDangNhap.setBackground(xanhDuong);
        btnDangNhap.setFocusPainted(false);
        btnDangNhap.setBorderPainted(false);
        btnDangNhap.setCursor(
            Cursor.getPredefinedCursor(Cursor.HAND_CURSOR)
        );
        btnDangNhap.setAlignmentX(Component.LEFT_ALIGNMENT);
        btnDangNhap.setMaximumSize(
            new Dimension(Integer.MAX_VALUE, 46)
        );
        btnDangNhap.setPreferredSize(new Dimension(300, 46));

        btnDangNhap.addActionListener(e -> xuLyDangNhap());
        btnDangNhap.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseEntered(java.awt.event.MouseEvent e) {
                btnDangNhap.setBackground(new Color(29, 78, 216));
            }

            @Override
            public void mouseExited(java.awt.event.MouseEvent e) {
                btnDangNhap.setBackground(xanhDuong);
            }
        });

        panel.add(btnDangNhap);
        panel.add(Box.createVerticalGlue());

        JLabel footer = new JLabel(
            "Vui lòng sử dụng tài khoản được cấp"
        );
        footer.setFont(new Font("Arial", Font.PLAIN, 11));
        footer.setForeground(new Color(148, 163, 184));
        footer.setAlignmentX(Component.CENTER_ALIGNMENT);
        panel.add(footer);

        getRootPane().setDefaultButton(btnDangNhap);

        return panel;
    }

    private JLabel createLabel(String text) {
        JLabel label = new JLabel(text);
        label.setFont(new Font("Arial", Font.BOLD, 11));
        label.setForeground(new Color(51, 65, 85));
        label.setAlignmentX(Component.LEFT_ALIGNMENT);
        label.setBorder(new EmptyBorder(0, 0, 8, 0));
        return label;
    }

    private void styleTextField(JTextField field) {
        field.setFont(new Font("Arial", Font.PLAIN, 14));
        field.setForeground(new Color(30, 41, 59));
        field.setBackground(new Color(248, 250, 252));
        field.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(
                new Color(203, 213, 225), 1
            ),
            new EmptyBorder(10, 12, 10, 12)
        ));
        field.setMaximumSize(new Dimension(Integer.MAX_VALUE, 44));
        field.setPreferredSize(new Dimension(300, 44));
        field.setAlignmentX(Component.LEFT_ALIGNMENT);
    }

    private void xuLyDangNhap() {
        String tenDangNhap = txtTenDangNhap.getText().trim();
        String matKhau = new String(txtMatKhau.getPassword());

        if (tenDangNhap.isEmpty() || matKhau.isEmpty()) {
            JOptionPane.showMessageDialog(
                this,
                "Vui lòng nhập tên đăng nhập và mật khẩu!",
                "Thiếu thông tin",
                JOptionPane.WARNING_MESSAGE
            );
            return;
        }

        btnDangNhap.setEnabled(false);
        btnDangNhap.setText("ĐANG KIỂM TRA...");

        try {
            TaiKhoanDAO dao = new TaiKhoanDAO();
            TaiKhoan taiKhoan = dao.dangNhap(
                tenDangNhap, matKhau
            );

            if (taiKhoan == null) {
                JOptionPane.showMessageDialog(
                    this,
                    "Tên đăng nhập hoặc mật khẩu không đúng!",
                    "Đăng nhập thất bại",
                    JOptionPane.ERROR_MESSAGE
                );
                txtMatKhau.setText("");
                txtMatKhau.requestFocus();
                return;
            }

            String vaiTro = taiKhoan.getVaiTro();

            if (!"Admin".equalsIgnoreCase(vaiTro)
                    && !"giangvien".equalsIgnoreCase(vaiTro)
                    && !"SinhVien".equalsIgnoreCase(vaiTro)) {
                JOptionPane.showMessageDialog(
                    this,
                    "Vai trò tài khoản không hợp lệ!",
                    "Thông báo",
                    JOptionPane.ERROR_MESSAGE
                );
                return;
            }

          dispose();

SwingUtilities.invokeLater(() -> {
    SinhVienView mainView = new SinhVienView(taiKhoan);
    new SinhVienController(mainView);
    mainView.setVisible(true);
});
        } finally {
            if (isDisplayable()) {
                btnDangNhap.setEnabled(true);
                btnDangNhap.setText("ĐĂNG NHẬP");
            }
        }
    }

    private class GradientPanel extends JPanel {
        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);

            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(
                RenderingHints.KEY_RENDERING,
                RenderingHints.VALUE_RENDER_QUALITY
            );

            GradientPaint gradient = new GradientPaint(
                0, 0, xanhDam,
                getWidth(), getHeight(),
                new Color(37, 99, 235)
            );

            g2.setPaint(gradient);
            g2.fillRect(0, 0, getWidth(), getHeight());
            g2.dispose();
        }
    }
}
